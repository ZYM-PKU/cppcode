#include<bits/stdc++.h>
using namespace std;
int main(){
    long long count=0;
    while(1){
        try{
            int* newint =new int[10];
            count++;
        }
        catch(bad_alloc){
            cout<<"共申请了： "<<count*sizeof(int)*10<<" 字节"<<endl;
            break;//经内存压力测试，共申请了24727228880个字节的内存空间，约为23.029GB大小。
            //（电脑物理内存为16G，程序运行期间调用了磁盘空间作为虚拟内存）
        }
    }
    return 0;
}