#include<bits/stdc++.h>
using namespace std;

//本例构造了CArray类用于动态申请内存存放可变长的字符序列
class CArray{
    int size;//除去最后一个空字符的字符数
    char *ptr;
public:
    CArray(int s=0);
    CArray(CArray& a);
    ~CArray();
    void push_back(char v);
    CArray & operator=(const CArray &a);
    int length(){return size;}
    char& operator[](int i){return ptr[i];}
    friend ostream& operator<<(ostream& os,CArray& ca);

};

CArray::CArray(int s):size(s){
    if(s==0)ptr=NULL;
    else {
        ptr=new char[s+1];
        memset(ptr,0,sizeof(char)*(s+1));
    }

}
CArray::CArray(CArray& a){
    if(!a.ptr){
        ptr=NULL;size=0;return;
    }
    ptr=new char[a.size+1];
    strcpy(ptr,a.ptr);
    size=a.size;
}
CArray::~CArray(){
    if(ptr)delete[]ptr;
}
CArray& CArray::operator=(const CArray &a){
    if(ptr==a.ptr)return *this;
    if(a.ptr==NULL){
        if(ptr)delete[]ptr;
        ptr=NULL;
        size=0;
        return *this;
    }
    if(size<a.size){
        if(ptr)delete[]ptr;
        ptr=new char[a.size+1];
    }
    strcpy(ptr,a.ptr);
    size=a.size;
    return *this;
}

void CArray::push_back(char v){
    if(ptr){
        if(_msize(ptr)/sizeof(char)<size+2){
            char* temp=new char[2*size+1];//2倍申请内存，提高申请效率
            memset(temp,0,sizeof(char)*(2*size+1));
            strcpy(temp,ptr);
            delete[] ptr;
            ptr=temp;
        }
    }
    else {
        ptr=new char[2];
        memset(ptr,0,sizeof(char)*2);
    }
    ptr[size++]=v;
}

ostream& operator<<(ostream& os,CArray& ca){
    os<<ca.ptr;
    return os;
}

int main(){
    CArray char_array;
    while(1){
        char c;
        cin.get(c);
        if(c=='!')break;//程序默认不读入感叹号
        char_array.push_back(c);
    }
    cout<<char_array<<endl;
    CArray b(char_array);
    b.push_back('1');
    char_array=b;
    cout<<char_array;
    
    return 0;
}